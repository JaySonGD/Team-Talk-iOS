/************************************************************
 * @file         TcpProtocolHeader.h
 * @author       快刀<kuaidao@mogujie.com>
 * summery       tcp服务器协议头，包括每个service下的command Id定义
 ************************************************************/

#import "DDTcpProtocolHeader.h"

@implementation DDTcpProtocolHeader

@end
