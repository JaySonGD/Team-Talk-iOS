//
//  LogoutAPI.h
//  TeamTalk
//
//  Created by Michael Scofield on 2014-10-20.
//  Copyright (c) 2014 dujia. All rights reserved.
//

#import "DDSuperAPI.h"

@interface LogoutAPI : DDSuperAPI

@end
