//
//  DDUserDetailInfoAPI.h
//  Duoduo
//
//  Created by 独嘉 on 14-5-22.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import "DDSuperAPI.h"

@interface DDUserDetailInfoAPI : DDSuperAPI

@end
