//
//  DDReceiveGroupAddMemberAPI.h
//  Duoduo
//
//  Created by 独嘉 on 14-5-8.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import "DDUnrequestSuperAPI.h"

@interface DDReceiveGroupAddMemberAPI : DDUnrequestSuperAPI

@end
