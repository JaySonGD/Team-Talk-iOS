//
//  RemoveSessionAPI.h
//  TeamTalk
//
//  Created by Michael Scofield on 2014-12-10.
//  Copyright (c) 2014 dujia. All rights reserved.
//

#import "DDSuperAPI.h"

@interface RemoveSessionAPI : DDSuperAPI

@end
