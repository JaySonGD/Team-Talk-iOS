//
//  DDDeleteMemberFromGroupAPI.h
//  Duoduo
//
//  Created by 独嘉 on 14-5-8.
//  Copyright (c) 2014年 zuoye. All rights reserved.
//

#import "DDSuperAPI.h"
/**
 *  移除讨论组中的某个用户,index1:groupId,index2:userlist
 */
@interface DDDeleteMemberFromGroupAPI : DDSuperAPI

@end
