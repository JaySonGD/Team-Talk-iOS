//
//  NSData+Conversion.h
//  TeamTalk
//
//  Created by Michael Scofield on 2015-01-06.
//  Copyright (c) 2015 dujia. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (Conversion)
#pragma mark - String Conversion
- (NSString *)hexadecimalString;
@end
