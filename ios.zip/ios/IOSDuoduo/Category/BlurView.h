//
//  BlurView.h
//  TeamTalk
//
//  Created by Michael Scofield on 2015-02-09.
//  Copyright (c) 2015 Michael Hu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BlurView : UIView
@property (nonatomic, strong) UIColor *blurTintColor;

@end
