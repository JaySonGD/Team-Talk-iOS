//
//  NSDate+DDAddition.h
//  IOSDuoduo
//
//  Created by 独嘉 on 14-6-5.
//  Copyright (c) 2014年 dujia. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (DDAddition)
- (NSString*)transformToFuzzyDate;
- (NSString*)promptDateString;
@end
