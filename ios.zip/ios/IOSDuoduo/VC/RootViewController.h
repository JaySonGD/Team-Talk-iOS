//
//  RootViewController.h
//  TeamTalk
//
//  Created by Michael Scofield on 2015-01-28.
//  Copyright (c) 2015 Michael Hu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController
@end
