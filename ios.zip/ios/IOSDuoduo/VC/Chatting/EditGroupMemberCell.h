//
//  EditGroupMemberCell.h
//  TeamTalk
//
//  Created by scorpio on 14/12/24.
//  Copyright (c) 2014年 dujia. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditGroupMemberCell : UITableViewCell{
    UIImageView* _delImg;
    UIImageView* _avatar;
    UILabel* _name;
}

@end
